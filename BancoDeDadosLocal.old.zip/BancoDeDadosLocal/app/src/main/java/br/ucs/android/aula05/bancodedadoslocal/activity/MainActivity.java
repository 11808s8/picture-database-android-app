package br.ucs.android.aula05.bancodedadoslocal.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import br.ucs.android.aula05.bancodedadoslocal.R;
import br.ucs.android.aula05.bancodedadoslocal.adapter.LivrosAdapter;
import br.ucs.android.aula05.bancodedadoslocal.banco.BDSQLiteHelper;
import br.ucs.android.aula05.bancodedadoslocal.model.Livro;

public class MainActivity extends AppCompatActivity {

    private BDSQLiteHelper bd;
    ArrayList<Livro> listaLivros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bd = new BDSQLiteHelper(this);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LivroActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        listaLivros = bd.getAllLivros();

        ListView lista = (ListView) findViewById(R.id.lvLivros);
        LivrosAdapter adapter = new LivrosAdapter(this, listaLivros);
        lista.setAdapter(adapter);


        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Intent intent = new Intent(MainActivity.this, EditarLivroActivity.class);
                intent.putExtra("ID", listaLivros.get(position).getId());
                startActivity(intent);
            }
        });
    }
}
